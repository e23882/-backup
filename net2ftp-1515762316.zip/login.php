<html>
	<head>
		<title>會員登入</title>
	</head>

	<body>
		
		<form method="post" action ="check_id.php"><br><br>
			帳號
			<input type="text" name="acc_name">
			<br><br>
			密碼
			<input type="password" name="acc_pw">
			<input type="button" name="acc_pw">
			<br><br><br>
			<input type = "submit" value="登入">
			
			<input type = "reset" value="清除"></a><br><br><br><br><br><br>
			<a class ="save" >
			<a href="register.php" class="btn btn-5"><span style="text-align:center;">註冊會員</span></a> 
			<a href="home.html" class="btn btn-5"><span style="text-align:center;">首頁</span></a> 
		
		</form>
	</body>

</html>
<?php
$GLOBALS["serverName"]   = "sql100.byethost33.com";
$GLOBALS["databaseName"] = "b33_19049243_yee";
$GLOBALS["dbuser"]       = "b33_19049243";
$GLOBALS["dbpassword"]   = "801128";
?>
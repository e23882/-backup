<meta name="viewport" content="width=device-width, initial-scale= 1.0, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Content-Type" content=""text/html; charset=utf-8>
<form  method="post" action ="saveQA.php" >
	<div>
		<input type="text" name="Q" placeholder="問題(新增?)" style="width:90%; font-size:14px; padding:6px 1%; margin-bottom:15px; background-color:#e6e6e6; border:1px solid #999; color:#666; outline:none; "/><br>
		
		<input type="text" name="title" placeholder="問題(ch標題?)"style="width:90%; font-size:14px; padding:6px 1%; margin-bottom:15px; background-color:#e6e6e6; border:1px solid #999; color:#666; outline:none; "/><br>
	</div>
	<div>
		<textarea name="content" placeholder="內容" style="width:90%; font-size:14px; padding:6px 1%; margin-bottom:15px; background-color:#e6e6e6; border:1px solid #999; color:#666; outline:none; height:80px;"></textarea><br>
	</div>
	<div style="text-align:right; padding-right:10%;;">
		<input type="submit" value="送出" style="width:20%; font-size:14px; padding:6px 1%; margin-bottom:15px; background-color:#f0f0f0; border:1px solid #999; color:#666; outline:none; "/>
	</div>
</form>